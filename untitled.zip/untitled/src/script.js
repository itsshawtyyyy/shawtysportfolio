(function () {
    var PLACEHOLDER = 'data:image/gif;base64,R0lGODlhAQABAIAAAAAAAP///yH5BAEAAAAALAAAAAABAAEAAAIBRAA7';
    var lastFocused = null;
    var closeTimer = null;

    function isZoomableSrc(src) {
        return src && src.indexOf(PLACEHOLDER) !== 0;
    }

    function getImgUrl(img) {
        return img.currentSrc || img.getAttribute('src') || img.src || '';
    }

    function initProjectImageLightbox() {
        var modal      = document.getElementById('proj-img-lightbox');
        if (!modal) return;

        var modalImg   = modal.querySelector('.proj-img-lightbox__img');
        var imgWrap    = modal.querySelector('#proj-img-wrap');
        var backdrop   = modal.querySelector('.proj-img-lightbox__backdrop');
        var btnClose   = modal.querySelector('.proj-img-lightbox__close');
        var panel      = modal.querySelector('.proj-img-lightbox__panel');
        var captionEl  = modal.querySelector('#proj-img-caption');
        var zoomLvlEl  = modal.querySelector('#proj-zoom-level');
        var btnZoomIn  = modal.querySelector('#proj-zoom-in');
        var btnZoomOut = modal.querySelector('#proj-zoom-out');
        var btnReset   = modal.querySelector('#proj-zoom-reset');

        var scale = 1, MIN_SCALE = 1, MAX_SCALE = 5;
        var tx = 0, ty = 0;
        var dragging = false, dragX0 = 0, dragY0 = 0, txStart = 0, tyStart = 0;
        var pinchDist0 = 0;

        function clamp(v, lo, hi) { return v < lo ? lo : v > hi ? hi : v; }

        function maxTranslate(sc) {
            if (!imgWrap || !modalImg) return { mx: 0, my: 0 };
            var ww = imgWrap.clientWidth, wh = imgWrap.clientHeight;
            var iw = modalImg.naturalWidth || modalImg.offsetWidth;
            var ih = modalImg.naturalHeight || modalImg.offsetHeight;
            if (!iw || !ih) return { mx: 0, my: 0 };
            var rendW, rendH;
            if (iw / ih > ww / wh) { rendW = ww; rendH = ww * ih / iw; }
            else { rendH = wh; rendW = wh * iw / ih; }
            return { mx: Math.max(0, (rendW * sc - ww) / 2), my: Math.max(0, (rendH * sc - wh) / 2) };
        }

        function applyTransform() {
            var m = maxTranslate(scale);
            tx = clamp(tx, -m.mx, m.mx);
            ty = clamp(ty, -m.my, m.my);
            modalImg.style.transform = 'scale(' + scale.toFixed(4) + ') translate(' + (tx / scale).toFixed(2) + 'px,' + (ty / scale).toFixed(2) + 'px)';
            if (zoomLvlEl)  zoomLvlEl.textContent = Math.round(scale * 100) + '%';
            if (btnZoomIn)  btnZoomIn.disabled  = scale >= MAX_SCALE;
            if (btnZoomOut) btnZoomOut.disabled = scale <= MIN_SCALE;
            if (imgWrap)    imgWrap.classList.toggle('is-pannable', scale > 1);
        }

        function resetZoom() {
            scale = 1; tx = 0; ty = 0;
            if (modalImg) modalImg.style.transform = '';
            if (zoomLvlEl)  zoomLvlEl.textContent = '100%';
            if (btnZoomIn)  btnZoomIn.disabled  = false;
            if (btnZoomOut) btnZoomOut.disabled = true;
            if (imgWrap) { imgWrap.classList.remove('is-pannable'); imgWrap.classList.remove('is-grabbing'); }
        }

        function zoomTo(newScale, cx, cy) {
            newScale = clamp(newScale, MIN_SCALE, MAX_SCALE);
            if (newScale === scale) return;
            tx = cx + (tx - cx) * (newScale / scale);
            ty = cy + (ty - cy) * (newScale / scale);
            scale = newScale;
            applyTransform();
        }

        if (imgWrap) {
            imgWrap.addEventListener('wheel', function (e) {
                e.preventDefault();
                var r = imgWrap.getBoundingClientRect();
                zoomTo(scale * (e.deltaY < 0 ? 1.14 : 1 / 1.14),
                       e.clientX - r.left - r.width / 2,
                       e.clientY - r.top  - r.height / 2);
            }, { passive: false });

            imgWrap.addEventListener('mousedown', function (e) {
                if (scale <= 1) return;
                dragging = true; dragX0 = e.clientX; dragY0 = e.clientY;
                txStart = tx; tyStart = ty;
                imgWrap.classList.add('is-grabbing'); e.preventDefault();
            });
            window.addEventListener('mousemove', function (e) {
                if (!dragging) return;
                tx = txStart + (e.clientX - dragX0);
                ty = tyStart + (e.clientY - dragY0);
                applyTransform();
            });
            window.addEventListener('mouseup', function () {
                if (!dragging) return;
                dragging = false;
                if (imgWrap) imgWrap.classList.remove('is-grabbing');
            });

            imgWrap.addEventListener('touchstart', function (e) {
                if (e.touches.length === 2) {
                    var dx = e.touches[0].clientX - e.touches[1].clientX;
                    var dy = e.touches[0].clientY - e.touches[1].clientY;
                    pinchDist0 = Math.sqrt(dx * dx + dy * dy);
                    dragging = false; e.preventDefault();
                } else if (e.touches.length === 1 && scale > 1) {
                    dragging = true;
                    dragX0 = e.touches[0].clientX; dragY0 = e.touches[0].clientY;
                    txStart = tx; tyStart = ty; e.preventDefault();
                }
            }, { passive: false });

            imgWrap.addEventListener('touchmove', function (e) {
                if (e.touches.length === 2 && pinchDist0 > 0) {
                    var dx = e.touches[0].clientX - e.touches[1].clientX;
                    var dy = e.touches[0].clientY - e.touches[1].clientY;
                    var dist = Math.sqrt(dx * dx + dy * dy);
                    var r = imgWrap.getBoundingClientRect();
                    zoomTo(scale * (dist / pinchDist0),
                           (e.touches[0].clientX + e.touches[1].clientX) / 2 - r.left - r.width / 2,
                           (e.touches[0].clientY + e.touches[1].clientY) / 2 - r.top  - r.height / 2);
                    pinchDist0 = dist; e.preventDefault();
                } else if (e.touches.length === 1 && dragging) {
                    tx = txStart + (e.touches[0].clientX - dragX0);
                    ty = tyStart + (e.touches[0].clientY - dragY0);
                    applyTransform(); e.preventDefault();
                }
            }, { passive: false });

            imgWrap.addEventListener('touchend', function (e) {
                if (e.touches.length < 2) pinchDist0 = 0;
                if (e.touches.length === 0) dragging = false;
            });

            imgWrap.addEventListener('dblclick', function (e) {
                if (scale > 1) {
                    resetZoom();
                } else {
                    var r = imgWrap.getBoundingClientRect();
                    zoomTo(2.5, e.clientX - r.left - r.width / 2, e.clientY - r.top - r.height / 2);
                }
            });
        }

        if (btnZoomIn)  btnZoomIn.addEventListener('click',  function () { zoomTo(scale * 1.35, 0, 0); });
        if (btnZoomOut) btnZoomOut.addEventListener('click', function () { zoomTo(scale / 1.35, 0, 0); });
        if (btnReset)   btnReset.addEventListener('click',   resetZoom);

        function openModal(src, alt, caption, triggerEl) {
            if (!isZoomableSrc(src)) return;
            if (closeTimer) { clearTimeout(closeTimer); closeTimer = null; }
            lastFocused = triggerEl || document.activeElement;
            function show() {
                resetZoom();
                modalImg.src = src;
                modalImg.alt = alt || 'Anteprima progetto';
                if (captionEl) captionEl.textContent = caption || '';
                modal.removeAttribute('hidden');
                modal.setAttribute('aria-hidden', 'false');
                modal.classList.add('is-open');
                document.body.classList.add('proj-img-lightbox-open');
                requestAnimationFrame(function () { if (btnClose) btnClose.focus({ preventScroll: true }); });
            }
            var preload = new Image();
            preload.onload = show; preload.onerror = show; preload.src = src;
        }

        function closeModal() {
            modal.classList.remove('is-open');
            modal.setAttribute('aria-hidden', 'true');
            document.body.classList.remove('proj-img-lightbox-open');
            resetZoom();
            if (closeTimer) clearTimeout(closeTimer);
            closeTimer = window.setTimeout(function () {
                closeTimer = null;
                if (modal.classList.contains('is-open')) return;
                modal.setAttribute('hidden', '');
                modalImg.removeAttribute('src'); modalImg.alt = '';
                if (captionEl) captionEl.textContent = '';
                if (lastFocused && typeof lastFocused.focus === 'function') lastFocused.focus({ preventScroll: true });
                lastFocused = null;
            }, 280);
        }

        function bindZoomable(img) {
            var src = img.getAttribute('src') || '';
            if (!isZoomableSrc(src)) { img.removeAttribute('title'); return; }
            img.classList.add('is-zoomable');
            img.setAttribute('tabindex', '0');
            img.setAttribute('role', 'button');
            img.setAttribute('title', 'Clicca per aprire l’anteprima');
            function activate(e) {
                if (e) e.preventDefault();
                var u = getImgUrl(img);
                if (!isZoomableSrc(u)) return;
                var frame = img.closest('.mockup-frame, .project-logo-frame');
                var caption = (frame && frame.getAttribute('data-caption')) || img.getAttribute('data-caption') || '';
                openModal(u, img.getAttribute('alt') || '', caption, img);
            }
            img.addEventListener('click', activate);
            img.addEventListener('keydown', function (e) { if (e.key === 'Enter' || e.key === ' ') activate(e); });
            var frame = img.closest('.mockup-frame, .project-logo-frame');
            if (frame && !frame.dataset.zoomBound) {
                frame.dataset.zoomBound = '1';
                frame.addEventListener('click', function (e) { if (e.target === img) return; activate(e); });
            }
        }

        document.querySelectorAll('.project-section .mockup-frame > img, .project-section .project-logo-frame > img').forEach(bindZoomable);

        if (backdrop) backdrop.addEventListener('click', closeModal);
        if (btnClose) btnClose.addEventListener('click', closeModal);
        if (panel) panel.addEventListener('click', function (e) { e.stopPropagation(); });
        document.addEventListener('keydown', function (e) {
            if (e.key === 'Escape' && modal.classList.contains('is-open')) closeModal();
        });
    }

    function initProjectsBook() {
        var book = document.querySelector('.projects-book');
        if (!book) return;

        var tabs = book.querySelectorAll('.project-tab');
        var panels = book.querySelectorAll('.projects-book__panels .project-section');
        var prevBtn = book.querySelector('.projects-book__arrow--prev');
        var nextBtn = book.querySelector('.projects-book__arrow--next');
        var current = 0;

        function showPanel(index) {
            if (index < 0 || index >= panels.length) return;
            current = index;

            tabs.forEach(function (tab, i) {
                var on = i === index;
                tab.classList.toggle('is-active', on);
                tab.setAttribute('aria-selected', on ? 'true' : 'false');
            });

            panels.forEach(function (panel, i) {
                var on = i === index;
                panel.classList.toggle('is-active', on);
                if (on) {
                    panel.removeAttribute('hidden');
                    panel.style.animation = 'none';
                    void panel.offsetHeight;
                    panel.style.animation = '';
                } else {
                    panel.setAttribute('hidden', '');
                }
            });

            if (prevBtn) prevBtn.disabled = index === 0;
            if (nextBtn) nextBtn.disabled = index === panels.length - 1;

            if (tabs[index] && tabs[index].scrollIntoView) {
                tabs[index].scrollIntoView({ block: 'nearest', behavior: 'smooth' });
            }
        }

        tabs.forEach(function (tab, i) {
            tab.addEventListener('click', function () {
                showPanel(i);
            });
        });

        if (prevBtn) {
            prevBtn.addEventListener('click', function () {
                showPanel(current - 1);
            });
        }

        if (nextBtn) {
            nextBtn.addEventListener('click', function () {
                showPanel(current + 1);
            });
        }

        book.addEventListener('keydown', function (e) {
            if (e.key !== 'ArrowLeft' && e.key !== 'ArrowRight') return;
            if (!book.contains(document.activeElement)) return;
            e.preventDefault();
            if (e.key === 'ArrowLeft') showPanel(current - 1);
            if (e.key === 'ArrowRight') showPanel(current + 1);
        });

        showPanel(0);
    }

    function initProcessoAnimation() {
        var steps = document.querySelectorAll('.processo-step');
        if (!steps.length) return;
        var observer = new IntersectionObserver(function(entries) {
            entries.forEach(function(entry) {
                if (entry.isIntersecting) {
                    entry.target.classList.add('is-visible');
                }
            });
        }, { threshold: 0.25 });
        steps.forEach(function(s) { observer.observe(s); });
    }

    function initBrandsCarousel() {
        var grid     = document.getElementById('brandsGrid');
        var prevBtn  = document.getElementById('brandsPrev');
        var nextBtn  = document.getElementById('brandsNext');
        if (!grid || !prevBtn || !nextBtn) return;

        var currentIndex = 0;

        function getVisible() {
            var vw = window.innerWidth;
            if (vw <= 500)  return 1;
            if (vw <= 900)  return 2;
            return 4;
        }

        function getTotal() {
            return grid.querySelectorAll('.brand-card').length;
        }

        function updateCarousel() {
            var cards   = grid.querySelectorAll('.brand-card');
            var visible = getVisible();
            var total   = cards.length;
            var maxIndex = Math.max(0, total - visible);
            currentIndex = Math.min(currentIndex, maxIndex);

            var cardW = cards[0] ? cards[0].offsetWidth : 0;
            var gap   = 20;
            var offset = currentIndex * (cardW + gap);
            grid.style.transform = 'translateX(-' + offset + 'px)';

            prevBtn.disabled = currentIndex === 0;
            nextBtn.disabled = currentIndex >= maxIndex;
        }

        prevBtn.addEventListener('click', function() {
            currentIndex = Math.max(0, currentIndex - 1);
            updateCarousel();
        });

        nextBtn.addEventListener('click', function() {
            var visible  = getVisible();
            var maxIndex = Math.max(0, getTotal() - visible);
            currentIndex = Math.min(maxIndex, currentIndex + 1);
            updateCarousel();
        });

        window.addEventListener('resize', function() {
            updateCarousel();
        });

        updateCarousel();
    }


    /* ─── GLOBE 3D ─────────────────────────────────────────────────────── */
    function initGlobe() {
        var scene = document.getElementById('globeScene');
        if (!scene) return;

        var tags  = Array.prototype.slice.call(scene.querySelectorAll('.globe-tag'));
        var N     = tags.length;
        var R     = scene.offsetWidth * 0.42; // orbit radius ≈ 42% of scene width
        var fov   = 500;

        /* Distribute N points evenly on a sphere via golden-angle spiral */
        var pts = tags.map(function(_, i) {
            var theta = Math.acos(1 - 2 * (i + 0.5) / N);
            var phi   = Math.PI * (1 + Math.sqrt(5)) * i;
            return {
                x: Math.sin(theta) * Math.cos(phi),
                y: Math.sin(theta) * Math.sin(phi),
                z: Math.cos(theta)
            };
        });

        var rotY        = 0;
        var rotX        = 0.25;            /* slight downward tilt */
        var speed       = 0.18;            /* current angular speed */
        var targetSpeed = 0.18;            /* slow idle */
        var raf;

        function render() {
            rotY  += speed * 0.012;
            speed += (targetSpeed - speed) * 0.04; /* smooth speed transition */

            var cosY = Math.cos(rotY), sinY = Math.sin(rotY);
            var cosX = Math.cos(rotX), sinX = Math.sin(rotX);

            var projected = pts.map(function(p, i) {
                /* rotate Y axis */
                var x1 = p.x * cosY - p.z * sinY;
                var z1 = p.x * sinY + p.z * cosY;
                var y1 = p.y;
                /* rotate X axis */
                var y2 = y1 * cosX - z1 * sinX;
                var z2 = y1 * sinX + z1 * cosX;
                /* perspective scale */
                var sc = fov / (fov + z2 * R * 0.6);
                return { px: x1 * R * sc, py: y2 * R * sc, z: z2, sc: sc, i: i };
            });

            /* sort back → front for correct layering */
            projected.sort(function(a, b) { return a.z - b.z; });

            projected.forEach(function(d) {
                var el      = tags[d.i];
                /* depth-based opacity: back=0.18, front=1 */
                var opacity = 0.18 + 0.82 * ((d.z + 1) / 2);
                /* depth-based blur: only on back hemisphere */
                var blur    = d.z < 0 ? Math.round(-d.z * 2.5) : 0;
                /* scale: slightly smaller at back */
                var tagSc   = 0.68 + 0.32 * ((d.z + 1) / 2);

                el.style.transform  = 'translate(calc(-50% + ' + d.px.toFixed(1) + 'px), calc(-50% + ' + d.py.toFixed(1) + 'px)) scale(' + tagSc.toFixed(3) + ')';
                el.style.opacity    = opacity.toFixed(3);
                el.style.zIndex     = Math.round(d.z * 10 + 10);
                el.style.filter     = blur > 0 ? 'blur(' + blur + 'px)' : 'none';
            });

            raf = requestAnimationFrame(render);
        }

        scene.addEventListener('mouseenter', function() {
            targetSpeed = 1.1;   /* speed up on hover */
        });
        scene.addEventListener('mouseleave', function() {
            targetSpeed = 0.18;  /* slow back down */
        });

        /* Pause when tab is hidden for perf */
        document.addEventListener('visibilitychange', function() {
            if (document.hidden) {
                cancelAnimationFrame(raf);
            } else {
                render();
            }
        });

        render();
    }

    function onReady() {
        initProjectsBook();
        initProjectImageLightbox();
        initProcessoAnimation();
        initBrandsCarousel();
        initGlobe();
    }

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', onReady);
    } else {
        onReady();
    }
})();